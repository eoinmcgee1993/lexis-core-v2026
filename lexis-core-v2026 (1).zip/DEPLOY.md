# LEXIS v2026.3 — Production Deployment Guide

## Prerequisites
- Node.js 18+
- OpenAI API key with Realtime API access
- Railway account (backend)
- Vercel account (frontend)
- GitHub repository

## Project Structure
```
lexis-core-v2026/
├── backend/
│   ├── server.mjs          # Token broker + rate limit + auth
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.jsx         # WebRTC client + visualizer + transcripts
│   │   ├── main.jsx
│   │   └── index.css       # Tailwind directives
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── package.json
├── railway.toml
├── vercel.json
└── DEPLOY.md
```

## Local Development

### 1. Backend
```bash
cd backend
cp .env.example .env
# Edit .env:
#   OPENAI_API_KEY=sk-proj-...
#   LEXIS_APP_SECRET=<generate-random-string>
#   ALLOWED_ORIGINS=http://localhost:5173

npm install
npm run dev
# → http://localhost:3001
# → Health check: http://localhost:3001/health
```

### 2. Frontend
```bash
cd frontend
cp .env.example .env.local
# Edit .env.local:
#   VITE_BACKEND_URL=http://localhost:3001
#   VITE_LEXIS_APP_SECRET=<same-as-backend>

npm install
npm run dev
# → http://localhost:5173
```

### 3. Test
- Open http://localhost:5173
- Click **INITIATE LEXIS** (or press Space)
- Allow microphone access
- Speak. Interrupt LEXIS mid-sentence to test barge-in.

## Production Deployment

### Backend → Railway
1. Push repo to GitHub.
2. Railway: **New Project** → **Deploy from GitHub repo**.
3. Railway auto-detects Node.js via `railway.toml`.
4. Railway Dashboard → **Variables**:
   - `OPENAI_API_KEY`
   - `LEXIS_APP_SECRET` (strong random string, 64+ chars)
   - `LEXIS_SALT` (any random string for hashing)
   - `ALLOWED_ORIGINS` (your Vercel domain, e.g. `https://lexis.vercel.app`)
   - `PORT` (Railway sets automatically)
5. Deploy. Railway provides URL: `https://lexis-api.up.railway.app`.

### Frontend → Vercel
1. Vercel: **Add New Project** → **Import Git Repository**.
2. Configure:
   - **Framework Preset**: Vite
   - **Root Directory**: `frontend`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
3. Vercel Dashboard → **Environment Variables**:
   - `VITE_BACKEND_URL` = Railway backend URL
   - `VITE_LEXIS_APP_SECRET` = same `LEXIS_APP_SECRET` from backend
4. Deploy.

### Post-Deployment
- [ ] Update `ALLOWED_ORIGINS` in Railway to match Vercel production domain
- [ ] Verify `/health` returns `{"status":"Operational"}`
- [ ] Test live session from Vercel URL
- [ ] Confirm mic permissions on mobile Safari/Chrome
- [ ] Set up Railway log drains for monitoring

## Security Checklist
- [ ] `LEXIS_APP_SECRET` is set and matches between backend/frontend
- [ ] `ALLOWED_ORIGINS` restricts CORS to production domain only
- [ ] `.env` files are in `.gitignore` and never committed
- [ ] `OpenAI-Safety-Identifier` headers are active (hashed IP + salt)
- [ ] Rate limiting is active (10 req/min per IP)

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `CORS policy violation` | Add Vercel domain to `ALLOWED_ORIGINS` |
| `401 Unauthorized` | Match `VITE_LEXIS_APP_SECRET` to `LEXIS_APP_SECRET` |
| `OpenAI API Error 404` | Check `OPENAI_MODEL` is valid Realtime model |
| No audio output | Browser autoplay policy requires user interaction first |
| High latency | User proximity to OpenAI edge (US/EU) matters |
| ICE failed | Corporate firewalls may need TURN server |
| Transcripts not showing | Check browser console for DataChannel errors |

## API Endpoint Migration Notes
This build uses OpenAI's **GA (General Availability)** endpoints:
- `POST /v1/realtime/client_secrets` — ephemeral token minting
- `POST /v1/realtime/calls?model=` — WebRTC SDP exchange
- Nested `session` schema with `session.type: "realtime"`

If you encounter 404s, verify your OpenAI account has Realtime API access.
