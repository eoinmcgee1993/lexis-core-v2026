# LEXIS OS v2026.3

**Language Engine & eXecutive Intelligence System**

A production-hardened, voice-native AI English tutor built on OpenAI Realtime API + native WebRTC. Designed for Thai youth ESL beta with sub-300ms latency, barge-in support, and real-time transcript streaming.

## Architecture

```
┌─────────────┐     POST /api/session      ┌─────────────┐
│   Browser   │ ◄────────────────────────► │   Node.js   │
│  (React 18) │    Ephemeral Token + Auth  │   Broker    │
└──────┬──────┘                            └──────┬──────┘
       │                                          │
       │  WebRTC PeerConnection (SDP Offer/Answer)│
       │  OPUS Audio + DataChannel Events         │
       ▼                                          ▼
┌─────────────────────────────────────────────────────────┐
│              OpenAI Realtime API (GA)                   │
│         gpt-4o-realtime-preview-2024-12-17              │
└─────────────────────────────────────────────────────────┘
```

## Reconciliation from Blueprint → v2026.3

| Dimension | Original Blueprint | v2026.3 (This Build) |
|-----------|-------------------|----------------------|
| **API Endpoint** | `POST /v1/realtime/sessions` (deprecated) | `POST /v1/realtime/client_secrets` (GA) |
| **WebRTC Endpoint** | `POST /v1/realtime?model=` (beta) | `POST /v1/realtime/calls?model=` (GA) |
| **Session Schema** | Flat (`voice`, `instructions` at root) | Nested (`session.audio.output.voice`) |
| **Auth** | Unauthenticated `cors(*)` | `x-lexis-app-token` + rate limiting |
| **Safety ID** | Missing | `OpenAI-Safety-Identifier` (SHA-256 hashed) |
| **VAD Tuning** | Aggressive 500ms silence | Thai ESL profile: 800ms silence, 0.5 threshold |
| **Pedagogy** | Generic tutor prompt | 15-25 word responses, gentle correction |
| **Voice** | `alloy` | `verse` |
| **UI** | Plain monospace terminal | Tailwind + lucide-react visualizer + transcript bubbles |
| **Audio Viz** | None | Real-time `AudioContext` + `AnalyserNode` |
| **Reconnect** | None | 3-attempt exponential backoff |
| **Cleanup** | Partial | Full track stop, PC close, DOM cleanup |

## Quick Start

```bash
# Terminal 1 — Backend
cd backend && npm install && cp .env.example .env && npm run dev

# Terminal 2 — Frontend
cd frontend && npm install && cp .env.example .env.local && npm run dev
```

Open http://localhost:5173, press **Space**, allow microphone, and speak.

## OS Engineering Modules

### Composite Vector Memory Eviction
When prompt budget reaches 80%, turns are scored via:
```
Score = 0.4·e^(-λΔt) + 0.3·RetrievalFrequency + 0.3·FactHeuristic
```
Items below 0.35 are evicted to vector cold storage.

### 40% Cost Reduction
1. Tool input response caching (25% reduction)
2. Rolling summary prompts (compress turns > 6 loops)
3. Dynamic model routing (Realtime for speech, text endpoints for diagnostics)

### Deterministic Replay
Every session generates a trace log with `session_id`, `vad_config`, and ordered `trace_events` for reproducible debugging.

## License
Proprietary — Digital Renaissance Ecosystem
