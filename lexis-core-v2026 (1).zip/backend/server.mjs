import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import crypto from 'crypto';

const app = express();
const PORT = process.env.PORT || 3001;

/* ─────────────────────────────────────────────────────────────────────── */
/* 1. STRICT CORS DOMAIN WHITELIST                                        */
/* ─────────────────────────────────────────────────────────────────────── */
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map(o => o.trim())
  : ['http://localhost:5173', 'http://127.0.0.1:5173'];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`[LEXIS Security] CORS blocked request from origin: ${origin}`));
    }
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-lexis-app-token']
}));

app.use(express.json());

/* ─────────────────────────────────────────────────────────────────────── */
/* 2. IN-MEMORY RATE LIMITING GUARD (10 req/min per IP)                   */
/* ─────────────────────────────────────────────────────────────────────── */
const rateLimitMap = new Map();

function rateLimiter(req, res, next) {
  const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown_client';
  const now = Date.now();
  const windowMs = 60 * 1000;
  const record = rateLimitMap.get(ip) || { count: 0, resetTime: now + windowMs };

  if (now > record.resetTime) {
    record.count = 1;
    record.resetTime = now + windowMs;
  } else {
    record.count += 1;
  }
  rateLimitMap.set(ip, record);

  if (record.count > 10) {
    return res.status(429).json({ error: 'Too many session requests. Rate limit exceeded.' });
  }
  next();
}

/* ─────────────────────────────────────────────────────────────────────── */
/* 3. APPLICATION SECURITY GUARD MIDDLEWARE                               */
/* ─────────────────────────────────────────────────────────────────────── */
function authenticateClientRequest(req, res, next) {
  const requiredAppToken = process.env.LEXIS_APP_SECRET;
  if (requiredAppToken) {
    const clientToken = req.headers['x-lexis-app-token'];
    if (!clientToken || clientToken !== requiredAppToken) {
      return res.status(401).json({ error: 'Unauthorized: Invalid or missing client application token.' });
    }
  }
  next();
}

/* ─────────────────────────────────────────────────────────────────────── */
/* 4. ENVIRONMENT VALIDATION                                              */
/* ─────────────────────────────────────────────────────────────────────── */
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
if (!OPENAI_API_KEY) {
  console.error('[LEXIS FATAL] OPENAI_API_KEY environment variable is not set.');
  process.exit(1);
}

/* ─────────────────────────────────────────────────────────────────────── */
/* 5. HEALTH CHECK                                                        */
/* ─────────────────────────────────────────────────────────────────────── */
app.get('/health', (req, res) => {
  res.json({
    status: 'Operational',
    engine: 'LEXIS OS v2026.3',
    timestamp: new Date().toISOString()
  });
});

/* ─────────────────────────────────────────────────────────────────────── */
/* 6. EPHEMERAL TOKEN ENDPOINT (GA — /v1/realtime/client_secrets)         */
/* ─────────────────────────────────────────────────────────────────────── */
app.post('/api/session', rateLimiter, authenticateClientRequest, async (req, res) => {
  try {
    // Generate anonymous user hash for OpenAI safety identification
    const userIp = req.ip || req.headers['x-forwarded-for'] || 'anonymous';
    const safetyIdentifier = crypto
      .createHash('sha256')
      .update(userIp + (process.env.LEXIS_SALT || 'lexis_salt'))
      .digest('hex')
      .substring(0, 32);

    // GA endpoint: client_secrets with nested session schema
    const response = await fetch('https://api.openai.com/v1/realtime/client_secrets', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
        'OpenAI-Safety-Identifier': safetyIdentifier
      },
      body: JSON.stringify({
        expires_after: {
          anchor: 'created_at',
          seconds: 600
        },
        session: {
          type: 'realtime',
          model: process.env.OPENAI_MODEL || 'gpt-4o-realtime-preview-2024-12-17',
          instructions: `You are LEXIS, an elite AI English language tutor designed specifically for Thai youth.
Speak clearly, naturally, warmly, and at a measured pace.
Keep each response short (15 to 25 words max) to maximize student speaking time.
Correct speech errors gently by providing the corrected phrase, then ask a simple follow-up question.
Be patient when the student pauses or hesitates.`,
          audio: {
            output: {
              voice: 'verse',
              format: 'pcm'
            },
            input: {
              transcription: {
                model: 'whisper-1'
              }
            }
          },
          turn_detection: {
            type: 'server_vad',
            threshold: 0.5,
            prefix_padding_ms: 400,
            silence_duration_ms: 800
          },
          max_response_output_tokens: 4096
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[LEXIS OpenAI Error]', response.status, errorText);
      return res.status(response.status).json({ error: 'Failed to mint ephemeral WebRTC session token.' });
    }

    const sessionData = await response.json();
    const ephemeralToken = sessionData.value;

    if (!ephemeralToken) {
      console.error('[LEXIS OpenAI Error] Unexpected response shape:', sessionData);
      return res.status(500).json({ error: 'No ephemeral token in OpenAI response.' });
    }

    res.json({
      client_secret: ephemeralToken,
      expires_at: sessionData.expires_at,
      session_id: sessionData.session?.id || null
    });

  } catch (err) {
    console.error('[LEXIS Internal Error]', err);
    res.status(500).json({ error: 'Internal server error initializing WebRTC session.' });
  }
});

/* ─────────────────────────────────────────────────────────────────────── */
/* 7. START                                                               */
/* ─────────────────────────────────────────────────────────────────────── */
app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`  LEXIS WebRTC Token Broker Active on Port ${PORT}`);
  console.log(`  Allowed Origins: ${allowedOrigins.join(', ')}`);
  console.log(`=======================================================`);
});
